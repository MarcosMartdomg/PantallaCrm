<script>
	import WelcomeScreen from './WelcomeScreen.svelte';
  </script>
  
  <WelcomeScreen />
  