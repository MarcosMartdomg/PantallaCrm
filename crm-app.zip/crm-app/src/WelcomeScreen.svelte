<script>
  // Puedes agregar lógica si es necesario
</script>

<div class="contenedor-movil" style="background-image: url('/fondo.png');">
<div class="pantalla">
  <div class="contenido">
    <!-- Logotipo con imagen -->
    <div class="logo">
      <img class="logo-img" src="./Z.png" alt="Logo Zippi" />
    </div>
    <!-- Títulos -->
    <h1>ZIPPI</h1>
    <p>INSPIRED BY YOU</p>
    <!-- Botones -->
    <button class="boton-principal">Let’s Start</button>
    <button class="boton-secundario">
      <span class="icono">🌐</span>
      Language
    </button>
  </div>
</div>
</div>

<style>
.contenedor-movil {
  width: 400px;
  height: 840px;
  margin: 0 auto;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
}

.pantalla {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  width: 100%;
  padding: 20px;
  box-sizing: border-box;
  color: white;
  font-family: 'Arial', sans-serif;
}

.contenido {
  text-align: center;
  width: 100%;
}

.logo {
  margin-bottom: 30px;
}

.logo-img {
  width: 100px;
  height: auto;
}

h1 {
  font-size: 38px;
  margin: 0;
  margin-bottom: 20px;
}

p {
  margin: 10px 0 30px;
  font-size: 14px;
  letter-spacing: 1px;
}

.boton-principal {
  display: inline-block;
  padding: 15px 30px;
  font-size: 20px;
  color: #1e3c72;
  background-color: white;
  border: none;
  border-radius: 20px;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
  width: 70%;
}

.boton-principal:hover {
  background-color: #f0f0f0;
}

.boton-secundario {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 15px 30px;
  font-size: 18px;
  color: #1e3c72;
  background-color: white;
  border: 2px solid white;
  border-radius: 20px;
  cursor: pointer;
  width: 70%;
}

.boton-secundario .icono {
  margin-right: 8px;
}

.boton-secundario:hover {
  background-color: #f0f0f0;
}
</style>
